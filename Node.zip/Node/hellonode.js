function helloNode(name){
    console.log("Hello from node.JS " + name)
}
helloNode("kaykay")