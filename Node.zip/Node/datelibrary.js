var dateLibrary = function(){
    return Date()
}

exports.myDate = dateLibrary