var slideposition = document.getElementById("slideshow")
