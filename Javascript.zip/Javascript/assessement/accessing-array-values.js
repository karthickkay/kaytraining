var food = ['apple', 'pizza', 'peat'];
console.log(food[1])