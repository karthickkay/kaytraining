function math(a, b, c){
    a = a+ (b*c);
    return a
}
console.log(math(53,61,67))