var example = 'example string'
console.log(example.length);